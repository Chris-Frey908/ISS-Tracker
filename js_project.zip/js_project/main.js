async function getISSLocation() {
  try {
    const response = await fetch(
      "https://api.wheretheiss.at/v1/satellites/25544",
    );
    const data = await response.json();
    const { latitude, longitude } = data;
    document.getElementById("iss-location").textContent =
      `Breitengrad: ${latitude}, Längengrad: ${longitude}`;
    await getISSLocationDetails(latitude, longitude);
  } catch (error) {
    console.error("Error fetching ISS location:", error);
  }
}

async function getISSLocationDetails(latitude, longitude) {
  try {
    const response = await fetch(
      `https://geocode.xyz/${latitude},${longitude}?json=1&auth=331817877869430481180x118691`,
    );
    console.log(latitude);
    console.log(longitude);
    const data = await response.json();
    const prov = data.prov;
    const city = data.city;
    if (city == undefined) {
      document.getElementById("iss-location").textContent +=
        ` - Aktuell über dem Meer`;
    } else {
      document.getElementById("iss-location").textContent +=
        ` - Over ${city}, ${prov}`;
    }
  } catch (error) {
    console.error("Error fetching ISS location details:", error);
  }
}

getISSLocation();
